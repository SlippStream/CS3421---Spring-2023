#ifndef CS3421_NICKZIMANSKI_CLOCK_CLIENT_H
#define CS3421_NICKZIMANSKI_CLOCK_CLIENT_H

class clockClient
{
public:
    virtual void doCycleWork() = 0;
};

#endif